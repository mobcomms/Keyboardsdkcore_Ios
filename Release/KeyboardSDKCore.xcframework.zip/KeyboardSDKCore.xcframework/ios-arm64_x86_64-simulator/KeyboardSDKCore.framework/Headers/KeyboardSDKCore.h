//
//  KeyboardSDKCore.h
//  KeyboardSDKCore
//
//  Created by enlipleIOS1 on 2021/05/06.
//

#import <Foundation/Foundation.h>


//! Project version number for KeyboardSDKCore.
//FOUNDATION_EXPORT double KeyboardSDKCoreVersionNumber;

//! Project version string for KeyboardSDKCore.
FOUNDATION_EXPORT const unsigned char KeyboardSDKCoreVersionString[];

extern const unsigned char * KeyboardSDKCoreVersionStringPtr;

// In this header, you should import all the public headers of your framework using statements like #import <KeyboardSDKCore/PublicHeader.h>

#import <KeyboardSDKCore/UIImage+NinePatch.h>
